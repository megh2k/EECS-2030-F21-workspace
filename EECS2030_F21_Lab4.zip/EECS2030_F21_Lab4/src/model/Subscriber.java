package model;

public class Subscriber extends Follower{

	public Subscriber(String s, int a, int b) {
		this.name = "Subscriber "+s;
		this.follow = new String[a];		//channels to follow
		this.videos = new String[b];		//videos recommended by channels
		this.update = "";
		this.max_f = a;
		this.max_v = b;
		this.channel = new Channel[a];
	}

	@Override
	public String toString() {
		this.update = String.format("%s follows ", this.name);

		if(this.nof == 0 && this.nov == 0) {
			this.update += "no channels and has no recommended videos.";

		}
		else{	
			if(this.nof == 0) {
				this.update +="and has no followers.";
			}
			else {
				this.update += "[";

				for(int i=0; i<this.nof; i++) {
					this.update += this.follow[i];
					if(this.nof-i != 1) {
						this.update +=", ";

					}
				}
				this.update += "] ";

			}
			if(this.nov == 0 ) {
				this.update += "and has no recommended videos.";

			}
			else {
				this.update += "and is recommended <";

				for(int i=0; i<this.nov; i++) {
					this.update += this.videos[i];
					if(this.nov-i != 1) {
						this.update +=", ";

					}
				}
				this.update += ">.";
			}


		}
		return this.update;
	}

	public void watch(String s, int j) {		//s is video name uploaded by channel

		for(int i=0; i<this.noc; i++) {		//finding the channel name[] which uploaded s

			for(int k=0; k<this.channel[i].nov; k++) {		//finding channel video[]

				if(this.channel[i].videos[k].equals(s)) {		//if this channel released video named s

					this.channel[i].update_time(this.channel[i], j);


				}
			}
		}


	}



}
