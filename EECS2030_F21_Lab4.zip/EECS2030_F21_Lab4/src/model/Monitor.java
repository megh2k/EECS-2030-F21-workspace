package model;

public class Monitor extends Follower {

	protected double avg_watch = 0.0;
	protected int views = 0;
	protected int max_w = 0;//max watch time
	protected int watch_time = 0;

	public Monitor(String s, int a) {
		this.name = "Monitor "+s;
		this.follow = new String[a];
		this.update = "";
		this.channel = new Channel[a];
	}

	//	public void update_time(Channel c, int i) {
	//
	//		for(int j=0; j<this.noc; j++) {
	//			
	//			if(this.channel[j] ==c) {
	//				this.channel[j].views++;
	//				this.views++;
	//				this.channel[j].watch_time += i;
	//				this.channel[j].avg_watch = (this.channel[j].watch_time *1.0)/this.channel[j].views;
	//
	//				if(i > this.channel[j].max_w) {
	//					this.channel[j].max_w = i;
	//				}
	//
	//			}
	//		}
	//	}
	@Override
	public String toString() {		//this.update += String.format(" {#views: %d, max watch time: %d, avg watch time: %.2f}",
		this.update = String.format("%s follows ", this.name);

		if(this.nof == 0) {
			this.update += "no channels.";
		}
		else {
			this.update += "[";


			for(int f=0; f<this.noc; f++) {
				this.update += this.follow[f];		//channel name


				if(this.channel[f].views !=0) {

					this.update += String.format(" {#views: %d, max watch time: %d, avg watch time: %.2f}",
							this.channel[f].views, this.channel[f].max_w, this.channel[f].avg_watch);


				}
				if(this.nof-f != 1) {
					this.update +=", ";

				}

			}
			


			this.update += "].";
		}
		return this.update;
	}



}
