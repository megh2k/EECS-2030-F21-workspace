package model;

public class Follower{

	protected String name;		//follower person's name 
	protected String[] follow;		
	protected String[] videos;		
	protected int nof = 0;
	protected int nov = 0;
	protected String update;
	protected int max_f;
	protected int max_v;
	protected Channel[] channel;
	protected int noc = 0;

	
}
