package model;

public class Channel{

	protected String name;		//channel name
	protected Follower[] follow;		//follower names
	protected String[] videos;		//videos released
	protected int nof;
	protected int nov;
	protected String update;
	protected int watch_time = 0;
	protected int max_f;
	protected int max_v;


	protected Monitor[] monitor;
	protected int nom;

	protected double avg_watch = 0.0;
	protected int views = 0;
	protected int max_w = 0;//max watch time

	public Channel(String s, int a, int b) {
		this.name = s;
		this.max_f = a;
		this.max_v = b;
		this.follow = new Follower[a];
		this.videos = new String[b];
		this.monitor = new Monitor[a];
		this.nof = 0;
		this.nov = 0;
		this.nom = 0;
		this.update = "";	

	}


	public void update_time(Channel c, int i) {

		//updating time for all monitors

		this.views++;
		this.watch_time += i;
		this.avg_watch = (this.watch_time *1.0)/this.views;

		if(i > this.max_w) {
			this.max_w = i;
		}

		for(int k=0; k<this.nof; k++) {		//follow[] of Channel
			if(this.follow[k] instanceof Monitor) {
				Monitor m = (Monitor) this.follow[k];
				//channels[] of monitors
				for(int f=0; f<m.noc ; f++) {

					if(this.follow[k].channel[f].equals(c)) {
						m.channel[f].views ++;
						m.channel[f].watch_time +=i;
						m.channel[f].avg_watch = (m.channel[f].watch_time *1.0)/m.channel[f].views;
						if(i>m.channel[f].max_w) {
							m.channel[f].max_w = i;

						}
					}

				}


			}
		}

	}

	public void releaseANewVideo(String s) {
		this.videos[this.nov] = s;
		this.nov++;

		for(int i=0; i<this.nof; i++) {
			if(this.follow[i] instanceof Subscriber) {
				this.follow[i].videos[this.follow[i].nov] = s;
				this.follow[i].nov++;
			}
		}
	}

	public void follow(Follower f) {
		this.follow[this.nof] = f;
		f.follow[f.nof] = this.name;		//channel getting f1 as a follower, so f1 following channel too


		//need monitors to change time when called channel....

		if(f instanceof Monitor) {
			f.channel[f.noc] = new Channel(this.name, this.max_f, this.max_v);
		}
		else {
			f.channel[f.noc] = this;
		}
		f.noc++;


		f.nof++;
		this.nof++;

		if(f instanceof Monitor) {
			this.monitor[this.nom] = (Monitor) f;
			this.nom++;
		}
	}

	public void unfollow(Follower f) {
		int i=0;
		boolean flag = false;
		for(; i<this.nof && !flag; i++) {
			if(this.follow[i] == f) {
				this.follow[i] = null;
				flag = true;
			}
		}
		if(flag) {
			for(int j=i-1; j<this.nof; j++) {
				this.follow[j] = this.follow[j+1];
				this.nof--;
			}
		}
		//for follower
		int fi=0;
		boolean fflag = false;
		for(; fi<f.nof && !fflag; fi++) {
			if(f.follow[fi] == this.name) {
				f.follow[fi] = null;
				fflag = true;
			}
		}

		if(fflag) {
			for(int j=fi-1; j<f.nof; j++) {
				f.follow[j] = f.follow[j+1];
				f.nof--;
				f.channel[j] = f.channel[j+1];
				f.noc--;
			}
		}


	}


	@Override
	public String toString() {
		this.update = String.format("%s released ", this.name);

		if(this.nof == 0 && this.nov == 0) {
			this.update += "no videos and has no followers.";
		}

		else{	
			if(this.nov == 0 ) {
				this.update += "no videos ";

			}
			else {
				this.update += "<";

				for(int i=0; i<this.nov; i++) {
					this.update += this.videos[i];
					if(this.nov-i != 1) {
						this.update +=", ";

					}
				}
				this.update += "> ";
			}

			if(this.nof == 0) {
				this.update +="and has no followers.";
			}
			else {
				this.update += "and is followed by [";

				for(int i=0; i<this.nof; i++) {
					this.update += this.follow[i].name;
					if(this.nof-i != 1) {
						this.update +=", ";

					}
				}
				this.update += "].";

			}
		}

		return this.update;

	}

	public boolean equals(Object obj) {

		if(obj == null) {
			return false;
		}

		Channel c = (Channel) obj;

		return (this.name == c.name);

	}






}
