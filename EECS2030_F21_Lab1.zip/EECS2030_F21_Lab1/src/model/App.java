package model;

public class App {

	private String appName;
	private int Max_Rating;
	private Log[] updateHistory;
	private int[] forRating;
	private int nou;//latest version 
	private int nor;
	private double sumrating = 0;

	public App(String appName, int rating) {
		this.appName = appName;
		this.Max_Rating = rating;
		this.updateHistory = new Log[20];
		this.forRating = new int[15];
		this.nou = 0;
		this.nor = 0;

	}

	public String getName() {
		return this.appName;
	}

	public String getWhatIsNew() {
		if(this.nou==0) {
			return "n/a";
		}
		else {
			return updateHistory[nou-1].toString();
		}

	}
	public int getnou() {
		return this.nou;
	}

	public Log[] getUpdateHistory() {
		Log[] ls = new Log[this.nou];

		for(int i=0; i<this.nou; i++) {
			ls[i] = this.updateHistory[i];
		}
		return ls;
	}


public void releaseUpdate(String version) {
	updateHistory[nou] = new Log(version);
	nou++;
}

public Log getVersionInfo(String version) {
	Log f = null;
	if(this.nou == 0) {
		return null;
	}
	else {
		for(int i=0; i<this.nou; i++) {
			if(this.updateHistory[i].getVersion() == version) {
				f = updateHistory[i];
			}
		}
		return f;
	}

}

public String getRatingReport() {
	sumrating = 0;

	for(int i=1; i<=5; i++) {
		sumrating += forRating[i]*i;
	}
	double c = sumrating/this.nor;
	c =  Math.round(c*10)/10.0;
	String d = String.format("%.1f", c);
	if(c == 0) {
		return "No ratings submitted so far!";
	}
	else {
		return "Average of " +this.nor +" ratings: " +d +" (Score 5: "+this.forRating[5] +", Score 4: "+this.forRating[4]+", Score 3: "+this.forRating[3]+", Score 2: "+this.forRating[2]+", Score 1: "+this.forRating[1]+")";
	}
}
public void submitRating(int x) {

	for(int i=1; i<=5; i++) {
		if(i==x) {
			this.forRating[i]++;
		}
	}
	nor++;
}
public double avg(double x, int y) {	//sumrating,nor
	double c = x/y;
	return Math.round(c*10)/10.0;
}

@Override
public String toString() {
	if(avg(sumrating, nor) == 0) {
		return this.appName + " (Current Version: " +this.getWhatIsNew() + "; Average Rating: n/a)";
	}
	else {
		return this.appName + " (Current Version: " +this.getWhatIsNew() + "; Average Rating: " +avg(sumrating, nor)  +")";

	}
	
}








}





















