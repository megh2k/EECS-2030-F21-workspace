package model;

import java.util.Arrays;

public class AppStore {

	private String branchName;
	private int max_n;
	private App[] appNames;
	private int noa;
	private String[] apps;
	public AppStore(String x, int y) {
		this.branchName = x;
		this.max_n = y;
		this.noa = 0;
		this.appNames = new App[max_n];
		this.apps = new String[max_n];

	}

	public String getBranch() {
		return this.branchName;
	}

	public App getApp(String name) {
		App f = null;
		if(this.noa ==0) {
			return null;
		}
		else {
			for(int i=0; i<this.noa; i++) {
				if(this.appNames[i].getName() == name) {
					f = appNames[i];
				}
			}
			return f;
		}
	}

	public String[] getStableApps(int x) {
		
		int count = 0;
		for(int i=0; i<this.noa; i++) {
			if(appNames[i].getnou()>=2) {
				apps[this.noa] = appNames[i].getName();
				count++;
			}
		}
		String[] ls = new String[count];
		for(int i=0; i<count; i++) {
			ls[i] = appNames[i].toString();
		}
		return ls;

	}

	public void addApp(App a) {
		appNames[this.noa] = a;
		this.noa++;
	}
	public App[] getappNames() {
		return this.appNames;
	}

	@Override
	public String toString() {
		return "AppStore [appNames=" + Arrays.toString(appNames) + "]";
	}













}
