package model;

public class Log {
	
	private String version;
	private int getNumberOfFixes = 0;
	private String[] Fixes;
	private final int MAX_FIXES = 10;
		
	public Log(String version) {
		this.version = version;
		Fixes = new String[MAX_FIXES];
	}
	
	public String getVersion() {
		return this.version;
	}
	
	public int getNumberOfFixes() {
		return this.getNumberOfFixes;
	}
	
	public String getFixes() {
		String forNow = "[";
		
		for(int i=0; i<getNumberOfFixes; i++) {
			if(getNumberOfFixes-i == 1) {
				forNow += this.Fixes[i];
			}
			else {
				forNow += this.Fixes[i] +", ";
			}
			
		}
		forNow += "]";
		return forNow;
	}
	
	public void addFix(String fix) {
		this.Fixes[getNumberOfFixes] = fix;
		getNumberOfFixes++;
	}

	@Override
	public String toString() {
		return "Version " + this.version + " contains " + this.getNumberOfFixes +" fixes " +this.getFixes();
	}
	
	
	
	
	
	
	
	
	
	
}
