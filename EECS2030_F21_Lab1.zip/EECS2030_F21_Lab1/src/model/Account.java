package model;

public class Account {
	private String accountName;
	private AppStore store;
	private int nda;
	private String[] namesOfDownloadedApps;
	private String s = "";
	private String[] why;
	private String whyname;
	public Account(String name, AppStore store) {
		this.accountName = name;
		this.store = store;
		this.nda = 0;
		this.namesOfDownloadedApps = new String[50];
		s = "An account linked to the Canada store is created for " +this.accountName +".";

	}

	public String[] getNamesOfDownloadedApps() {

		
		if(s == whyname+" is successfully uninstalled for " +this.accountName +".") {
			return why;
		}
		else {
			String[] ls = new String[nda];
			for(int i=0; i<nda; i++) {
				ls[i] = this.namesOfDownloadedApps[i]; //this.namesOfDownloadedApps
			}
			return ls;
		}
		
		
	}



	public App[] getObjectsOfDownloadedApps() {

		App[] ls = new App[this.nda];
		for(int i=0; i<this.nda; i++) {
			ls[i] = this.store.getappNames()[i];
		}
		return ls;	
	}

	public void download(String x) {
		this.whyname = x;
		boolean flag = false;
		if(this.nda>=1) {
			for(int i=0; i<=this.nda; i++) {
				if(x.equals(this.namesOfDownloadedApps[i])) {	//this.namesDA
					flag = true;
					s = "Error: " +x +" has already been downloaded for " + accountName + ".";

				}
			}
		}
		if(flag==false) {
			this.namesOfDownloadedApps[this.nda] = x;
			s = this.namesOfDownloadedApps[this.nda] +" is successfully downloaded for " + accountName + ".";
			
			nda++;
		}

	}


	public void uninstall(String name) {
		boolean flag = false;
		String[] ls = new String[nda];
		for(int i=0; i<nda; i++) {
			ls[i] = this.namesOfDownloadedApps[i];
		}
		
		for(int i=0; i<nda; i++) {
			if(ls[i] == name) {
				s = name+" is successfully uninstalled for " +this.accountName +".";
				
				flag = true;
			}
		}
		if(flag == false) {
			s = "Error: "+name+" has not been downloaded for " +this.accountName +".";
		}

	}

	public void submitRating(String x, int y) {
		boolean flag = false;
		int i = 0;
		while(flag == false && i<this.nda) {
			if(x==this.namesOfDownloadedApps[i]) {
				flag = true;
				s = "Rating score "+y +" of " +this.accountName +" is successfully submitted for "+x +".";
				store.getApp(x).submitRating(y);
			}
			i++;
		}
		if(flag == false) {
			s = "Error: "+x +" is not a downloaded app for "+this.accountName +".";
		}

	}

	public void switchStore(AppStore x) {
		this.store = x;
		s = "Account for Suyeon is now linked to the "+ this.store.getBranch() +" store.";
	}




	@Override
	public String toString() {
		return s;
	}






}
