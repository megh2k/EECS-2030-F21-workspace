package junit_tests;

import static org.junit.Assert.*;

import org.junit.Test;

import model.Account;
import model.App;
import model.AppStore;
import model.Log;

public class PersonalTests {

//	@Test
//	public void test_log_01() {
//		/* Create a new app update log with a version number */
//		Log appUpdate = new Log("5.7.31");
//		
//		/* Retrieve the set version value. */
//		String v = appUpdate.getVersion();
//		assertEquals("5.7.31", v);
//		
//		/* Initially, no fixes have been added to the update log. */
//		int n = appUpdate.getNumberOfFixes();
//		assertEquals(0, n);
//		
//
//		String s1 = appUpdate.getFixes();
//		assertEquals("[]", s1);
//
//		String s2 = appUpdate.toString();
//		assertEquals("Version 5.7.31 contains 0 fixes []", s2); 
//		
////		Log appUpdate1 = new Log("5.7.52");
////		String v1 = appUpdate1.getVersion();
////		assertEquals("5.7.52", v1);
//	}
//	
//	@Test
//	public void test_log_02() {
//		/* Create a new app update log with a version number */
//		Log appUpdate = new Log("5.7.31");
//		
//		appUpdate.addFix("Addressed writing lag issues");
//		appUpdate.addFix("Fixed a bug about dismissing menus");
//		
//		assertEquals("5.7.31", appUpdate.getVersion());
//
//		assertEquals(2, appUpdate.getNumberOfFixes());
//	
//		
//		assertTrue(appUpdate.getNumberOfFixes() == 2);
//		assertEquals("[Addressed writing lag issues, Fixed a bug about dismissing menus]", appUpdate.getFixes());
//		assertEquals("Version 5.7.31 contains 2 fixes [Addressed writing lag issues, Fixed a bug about dismissing menus]", appUpdate.toString()); 
//	}
//	@Test
//	public void test_app_01() {
//		/* Create a new app with a name and the maximum number of ratings allowed to be submitted. */
//		App app = new App("GoodNotes 5", 15);
//
//		String s1 = app.getName();
//		assertEquals("GoodNotes 5", s1);
//		
//
//		String s2 = app.getWhatIsNew();
//		assertEquals("n/a", s2);
//
//		Log[] history = app.getUpdateHistory();
//		assertTrue(history.length == 0);
//		//System.out.println(history.length);
//		
//		/* Initially, no log object is associated with any version number. */
//		Log log = app.getVersionInfo("5.7.31");
//		//assertNull(log);
//		System.out.println(log);
//		
//		/* Initially, no ratings have been submitted by registered accounts. */
//		String s3 = app.getRatingReport();
//		assertEquals("No ratings submitted so far!", s3);
//		
//		/*
//		 * The string representation of an app object includes:
//		 * 	- its name
//		 * 	- log information of current/latest version/release (n/a when none have been released)
//		 * 	- an average of rating scores received so far (n/a when none have been submitted)
//		 */
//		String s4 = app.toString();
//		assertEquals("GoodNotes 5 (Current Version: n/a; Average Rating: n/a)", s4);
//	}
	
	@Test
	public void test_app_02() {
		/* Create a new app with a name and the maximum number of ratings allowed to be submitted. */
		App app = new App("GoodNotes 5", 15);
		
		/* Release three updates (by adding their version numbers).
		 * 
		 * See Section 2.3 of lab instructions for more details 
		 * 	(e.g., maximum number of updates allowed for an app). 
		 * No error handling is needed when the max limit is exceeded. 
		 */
		app.releaseUpdate("5.7.27");
		app.releaseUpdate("5.7.29");
		app.releaseUpdate("5.7.31");
		
		/* Retrieve the set name of the app. */
		assertEquals("GoodNotes 5", app.getName());
		
		/* Get information about the last-released version. */
		assertEquals("Version 5.7.31 contains 0 fixes []", app.getWhatIsNew());
		//System.out.println(app.getWhatIsNew());
		assertTrue(app.getUpdateHistory().length == 3);
		/* Retrieve the list of update log objects and compare their toString return values. */
		assertTrue(app.getUpdateHistory()[0].toString().equals("Version 5.7.27 contains 0 fixes []"));
		assertTrue(app.getUpdateHistory()[1].toString().equals("Version 5.7.29 contains 0 fixes []"));
		assertTrue(app.getUpdateHistory()[2].toString().equals("Version 5.7.31 contains 0 fixes []"));
		
		/* Add fixes to each stored update log. */
		app.getUpdateHistory()[0].addFix("Support for new M1 ipad Pro");
		app.getUpdateHistory()[1].addFix("Fixed a launch crash");
		app.getUpdateHistory()[1].addFix("Improved scroll animations");
		app.getUpdateHistory()[2].addFix("Better logging");
		app.getUpdateHistory()[2].addFix("Improved performance");
		app.getUpdateHistory()[2].addFix("Stability improvements");
		
		assertTrue(app.getUpdateHistory().length == 3);
		/* Retrieve the list of update log objects and compare their toString return values. */
		assertEquals("Version 5.7.27 contains 1 fixes [Support for new M1 ipad Pro]", app.getUpdateHistory()[0].toString());
		assertEquals("Version 5.7.29 contains 2 fixes [Fixed a launch crash, Improved scroll animations]", app.getUpdateHistory()[1].toString());
		assertEquals("Version 5.7.31 contains 3 fixes [Better logging, Improved performance, Stability improvements]", app.getUpdateHistory()[2].toString());
		
		/* Given a version number, if valid, retrieve the corresponding log object and compare its toString return value. */
		assertEquals("Version 5.7.27 contains 1 fixes [Support for new M1 ipad Pro]", app.getVersionInfo("5.7.27").toString());
		assertEquals("Version 5.7.29 contains 2 fixes [Fixed a launch crash, Improved scroll animations]", app.getVersionInfo("5.7.29").toString());
		assertEquals("Version 5.7.31 contains 3 fixes [Better logging, Improved performance, Stability improvements]", app.getVersionInfo("5.7.31").toString());
		/* No log object is associated with this non-existing version number. */
		//assertNull(app.getVersionInfo("5.7.33"));  
	}

}
