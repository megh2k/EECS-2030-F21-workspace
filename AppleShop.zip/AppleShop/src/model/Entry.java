package model;

public class Entry {
	private String serialNumber; //unique number
	
	/* 	Product is the type of attribute(reference type)
		this attribute will store address
	  	of some Product object
	*/
	private Product product;	
	
	public Entry(String serialNumber, Product product) {
		this.serialNumber = serialNumber;
		this.product = product;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	//overload constructor of setProduct mutator
	public void setProduct(String model, double originalPrice) {
		// this.product = model;.........not possible because the type of product is Product and model is String
		//this.product = new Product(model, originalPrice);
		Product p = new Product(model, originalPrice);
		this.product = p;
	}
	
	public String toString() {
		return"[" + this.serialNumber +"]" +" " +this.product.toString();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
