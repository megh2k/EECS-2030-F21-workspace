package model;

public class VaccineDistribution {
	
	private String str;
	
	public VaccineDistribution(Vaccine v, int distribution) {
		this.str = String.format("%d doses of %s by %s", distribution, v.getCodeName(), v.getManufacturer());
	}

	@Override
	public String toString() {
		return this.str;
	}
	
	

}
