package model;

import static org.junit.Assert.fail;


public class Trial {

	public static void main(String[] args) {

		VaccinationSite vs = new VaccinationSite("North York General Hospital", 10);

		Vaccine v1 = new Vaccine("mRNA-1273", "RNA", "Moderna");
		Vaccine v2 = new Vaccine("BNT162b2", "RNA", "Pfizer/BioNTech");
		Vaccine v3 = new Vaccine("AZD1222", "Non Replicating Viral Vector", "Oxford/AstraZeneca");
		
		try { 
			vs.addDistribution(v3, 1); /* 1st distribution of AZ */
			vs.addDistribution(v1, 1); /* 1st distribution of Moderna */
			vs.addDistribution(v3, 1);
			vs.addDistribution(v2, 1); /* 1st distribution of Pfizer */
			vs.addDistribution(v1, 1);
			
			HealthRecord alan = new HealthRecord("Alan", 5);
			HealthRecord mark = new HealthRecord("Mark", 5);
			HealthRecord tom = new HealthRecord("Tom", 5);
			HealthRecord jim = new HealthRecord("Jim", 5);
			
			vs.bookAppointment(alan);
			vs.bookAppointment(mark);
			vs.bookAppointment(tom); 

			vs.administer("April-23-2021");
			

			vs.bookAppointment(mark);
			vs.bookAppointment(jim);
			
			vs.administer("August-31-2021");
		}
		catch(UnrecognizedVaccineCodeNameException e) {
			fail("Unexpected exception thrown");
		}
		catch(TooMuchDistributionException e) {
			fail("Unexpected exception thrown");
		}
		catch(InsufficientVaccineDosesException e) {
			fail("Unexpected exception thrown");
		}
		
		for(int i=0; i<vs.getRecord().length; i++) {
			System.out.println(vs.getRecord()[i].getName());
		}
		
		for(int i=0; i<vs.getVacnum().length; i++) {
			System.out.println(vs.getVacnum()[i]);

		}
		for(int i=0; i<vs.getVaccines().length; i++) {
			System.out.println(vs.getVaccines()[i].getManufacturer());
		}
		
	}

}
