package model;

public class VaccinationSite {
	private String name;
	private int limit;
	private int noad = 0;	//number of available doses
	private int[] vacnum = new int[4];	//how many doses are available for each vaccine
	private String[] approvedVac = {"mRNA-1273", "BNT162b2", "Ad26.COV2.S", "AZD1222"};	//codenames
	private Vaccine[] addedVaccines;
	private HealthRecord[] appoint;
	public static int noa = 0; 	//number of appointments
	private int noav;	//available vaccines
	public static int nova;
	private int nod4 =0;
	private int noav4;
	private String date ="";
	String str = "";

	public VaccinationSite(String place, int limit) {
		this.name = place;
		this.limit = limit;
		this.addedVaccines = new Vaccine[4];
		this.noav = 0;
		this.noav4 = 0;
		this.appoint = new HealthRecord[200];
		VaccinationSite.nova = 0;
		VaccinationSite.noa = 0;
	}
	
	public Vaccine[] getVaccines() {
		return this.addedVaccines;
	}

	public int getNumberOfAvailableDoses() {
		return this.noad;
	}

	public int[] getVacnum() {
		return this.vacnum;
	}
	public int getNumberOfAvailableDoses(String s) {
		int n = 0;
		for(int i=0; i<this.noav; i++) {
			if(this.addedVaccines[i].getCodeName().equals(s)) {
				n += vacnum[i];
			}
		}
		return n;
	}

	public void addDistribution(Vaccine v, int l) throws UnrecognizedVaccineCodeNameException, TooMuchDistributionException  {
		boolean flag = false;

		for(int i=0; i<this.approvedVac.length && !flag; i++) {
			if(v.getCodeName().equals(this.approvedVac[i])) {
				flag = true;
			}
		}

		if(flag == false) {
			throw new UnrecognizedVaccineCodeNameException("Unexpected exception thrown");
		}
		else {	// if the vaccine is approved
			this.noad +=l;
			this.nod4 +=l;
			VaccinationSite.nova +=l;

			if(this.noav ==0) {
				this.addedVaccines[this.noav] = v;
				this.noav++;
				this.noav4++;

			}
			
			else {
				boolean f = false;
				for(int i=0; i<this.noav && !f; i++) {

					if(this.addedVaccines[i].getManufacturer().equals(v.getManufacturer())) {
						f = true;
					}
				}
				if(f == false) {
					this.addedVaccines[this.noav] = v;
					this.noav++;
					this.noav4++;

				}
			}
			Vaccine[] v1 = new Vaccine[this.noav];
			for(int i=0; i<this.noav; i++) {
				v1[i] = this.addedVaccines[i];
			}
			int sum = vacnum[0] + vacnum[1] +vacnum[2] +vacnum[3];
			
			if(this.limit>=sum+l) {
				this.str = String.format("%s has %d available doses: <", this.name, this.noad);	

				for(int i=0; i<this.noav ; i++) {

					if(v.getCodeName().equals(v1[i].getCodeName())) {	
						this.vacnum[i]+=l;
					}

					if(this.noav - i ==1) {
						this.str += String.format("%d doses of %s", this.vacnum[i], v1[i].getManufacturer());
					}

					else {
						this.str += String.format("%d doses of %s, ", this.vacnum[i], v1[i].getManufacturer());
					}						


				}
				this.str += ">";
			}
			
			else{
				throw new TooMuchDistributionException("Unexpected exception thrown");
			}
		}
	}
	
	public void bookAppointment(HealthRecord x) throws InsufficientVaccineDosesException {
		
		x.setPlaceName(this.getSiteName());		
		
		if(VaccinationSite.noa==this.noad) {
			VaccinationSite.nova --;
			throw new InsufficientVaccineDosesException("Expeted exception not thrown");			
		}
		
		else {
			boolean flag = false;
			for(int i=0; i<VaccinationSite.noa && !flag; i++) {
				if(this.appoint[i] == x) {
					flag = true;
				}
			}
			if(flag == false) {
				this.appoint[VaccinationSite.noa] = x;
				VaccinationSite.noa++;

			}
			VaccinationSite.nova --;
			this.noav--;
			this.nod4--;			
			boolean f = false;
			
			for(int i=0; i<this.vacnum.length && !f; i++) {
				
				if(this.vacnum[i] !=0) {
					if(HealthRecord.noo != 0) {
						HealthRecord.noo--;

					}
					x.addRecord(this.addedVaccines[i], this.name, this.date);
					this.vacnum[i]--;
					f = true;
				}
			}
		}
		
		Vaccine[] v1 = new Vaccine[this.noav4];
		for(int i=0; i<this.noav4; i++) {
			v1[i] = this.addedVaccines[i];
		}
		
		this.str = String.format("%s has %d available doses: <", this.name, this.nod4);	
		
		for(int i=0; i<this.noav4 ; i++) {
			
			if(this.noav4 - i ==1) {
				this.str += String.format("%d doses of %s", this.vacnum[i], v1[i].getManufacturer());
			}

			else {
				this.str += String.format("%d doses of %s, ", this.vacnum[i], v1[i].getManufacturer());
			}						
		}
		this.str += ">";

		
	}

	public HealthRecord[] getRecord() {
		HealthRecord[] r = new HealthRecord[VaccinationSite.noa];
		
		for(int i=0; i<VaccinationSite.noa; i++) {
			r[i] = this.appoint[i];
		}
		return r;
	}
	
	public String getSiteName() {
		return this.name;
	}
	
	public void administer(String s) {

		for(int i=0; i<this.appoint.length && this.appoint[i] != null; i++) {
			for(int j=0; j<this.appoint[i].getDate().length; j++) {
				boolean flag = false;
				
				if((this.appoint[i].getDate()[j] == null || this.appoint[i].getDate()[j] == "" ) && !flag ) {
					this.appoint[i].setDate(s);
					flag = true;
				}
			}
		}
	}
	
	@Override
	public String toString() {
		if(this.noad ==0 && VaccinationSite.noa ==0) {
			this.str = String.format("%s has 0 available doses: <>", this.name);
		}

		return this.str;
	}
	
	



}
