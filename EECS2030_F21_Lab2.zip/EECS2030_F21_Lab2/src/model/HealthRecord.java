package model;

public class HealthRecord {
	private String name;
	private int limit;
	private int nov;
	private String str = "";
	private Vaccine[] vac;
	private String[] place;
	private String[] date;
	private String placeName;
	public static int noo =0;

	public HealthRecord(String name, int limit) {
		this.place = new String[2];
		this.name = name;
		this.limit = limit;
		this.vac = new Vaccine[2];
		this.date = new String[2];
		this.placeName = "";
		HealthRecord.noo = 0;
	}
	
	public String getPlaceName() {
		return this.placeName;
	}
	public void setPlaceName(String s) {
		this.placeName = s;
	}
	
	public String[] getDate() {
		return this.date;
	}
	
	public void setDate(String s) {
		
		for(int i=0; i<this.date.length; i++) {
			this.date[i] = s;
		}
	}

	public String getVaccinationReceipt() {
		
		this.str =String.format("Number of doses %s has received: %d", this.name, this.nov);

		if(this.nov ==1) {
			this.str +=String.format(" [%s in %s on %s]",this.vac[HealthRecord.noo-1].toString(), this.place[HealthRecord.noo-1], this.date[HealthRecord.noo-1]);
		}

		else {
			for(int i=0; i<this.nov; i++) {

				if(this.nov-i == 1) {
					this.str += String.format(" %s in %s on %s]", this.vac[i].toString(), this.place[i], this.date[i]);
				}

				else {
					this.str += String.format(" [%s in %s on %s;", this.vac[i].toString(), this.place[i], this.date[i]);
				}

			}
		}
		if(this.nov ==0) {
			this.str = String.format("%s has not yet received any doses.", this.name);
		}

		return this.str;
	}

	public String getName() {
		return this.name;
	}

	public String getAppointmentStatus() {
		
		if(VaccinationSite.noa ==0) {
			this.str = String.format("No vaccination appointment for %s yet", this.name);
		}
		
		else if(VaccinationSite.nova<0){
			this.str = String.format("Last vaccination appointment for %s with %s failed", this.name, this.getPlaceName());
		}
		else {
			this.str = String.format("Last vaccination appointment for %s with %s succeeded", this.name, this.getPlaceName());
		}

		return this.str;
	}

	public int getLimit() {
		return this.limit;
	}

	public void addRecord(Vaccine v, String b, String c) {
		HealthRecord.noo ++;
		this.place[this.nov] = b;
		this.date[this.nov] = c;
		this.vac[this.nov] = v;
		this.nov++;
//		this.str =String.format("Number of doses %s has received: %d", this.name, this.nov);
//
//		if(this.nov ==1) {
//			this.str +=String.format(" [%s in %s on %s]",v.toString(), b, c);
//		}
//
//		else {
//			for(int i=0; i<this.nov; i++) {
//
//				if(this.nov-i == 1) {
//					this.str += String.format(" %s in %s on %s]", this.vac[i].toString(), this.place[i], this.date[i]);
//				}
//
//				else {
//					this.str += String.format(" [%s in %s on %s;", this.vac[i].toString(), this.place[i], this.date[i]);
//				}
//
//			}
//		}
	}

}
