package model;

public class Vaccine {
	
	private String codeName;
	private String typeName;
	private String manufacturer;
	private String[] approvedVac = {"mRNA-1273", "BNT162b2", "Ad26.COV2.S", "AZD1222"};	//codenames
	
	
	public Vaccine(String a, String b, String c) {
		this.codeName = a;
		this.typeName = b;
		this.manufacturer = c;
	}
	
	public String isApproved(String s) {
		String str = "";
		
		boolean flag = false;
		for(int i=0; i<this.approvedVac.length && !flag; i++) {
			if(s.equals(this.approvedVac[i])) {
				str = "Recognized vaccine:";
				flag = true;
			}
	
		}
		if(flag == false) {
			str = "Unrecognized vaccine:";
		}
		return str;
	}
	
	public String getCodeName() {
		return codeName;
	}

	public String getTypeName() {
		return typeName;
	}

	public String getManufacturer() {
		return manufacturer;
	}


	@Override
	public String toString() {	//"AZD1222", "Non Replicating Viral Vector", "Oxford/AstraZeneca"
		return String.format("%s %s (%s; %s)",isApproved(this.codeName) ,this.codeName, this.typeName, this.manufacturer);
	}
	
	

}
