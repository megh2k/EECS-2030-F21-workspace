package model;

public class ConcatAll extends SeqEvaluator {


	public ConcatAll(int x) {
		super(x);
		this.notconcat = 0;
	}


	public void addOperation(String s, int[] a, int[] b) throws IllegalOperationException {

		if(s.equals("op:projection")) {
			this.seqo[this.noco] = new Projection(a, b);
		}

		else if(s.equals("op:sumsOfPrefixes")){
			this.seqo[this.noco] = new SumsOfPrefixes(a);
		}
		
		else if(s.equals("op:occursWithin")) {
			this.notconcat ++;
			this.noco--;
		}
		else {
			throw new IllegalOperationException(s);
		}

		this.noco++;
	}

	public int[] getconCatAll() {
		return this.getconCatAll;
	}


	public int[] conCatAll() {

		int length = 0;

		for(int i=0; i<this.noco; i++) {
			if(this.seqo[i] instanceof Projection) {
				length += ((Projection) this.seqo[i]).getProjecting().length;

			}
			else if(this.seqo[i] instanceof SumsOfPrefixes) {
				length += ((SumsOfPrefixes) this.seqo[i]).getSumsofPrefixes().length;

			}
		}

		this.getconCatAll = new int[length];
		int index = 0;

		for(int i=0; i<this.noco; i++) {
			if(this.seqo[i] instanceof Projection) {

				int j=0; 
				while(j<((Projection) this.seqo[i]).getProjecting().length){

					this.getconCatAll[index] = ((Projection) this.seqo[i]).getProjecting()[j];
					j++;
					index++;
				}
			}
			else {
				int j=0; 
				while(j<((SumsOfPrefixes) this.seqo[i]).getSumsofPrefixes().length){

					this.getconCatAll[index] = ((SumsOfPrefixes) this.seqo[i]).getSumsofPrefixes()[j];
					j++;
					index++;
				}

			}
		}

		return this.getconCatAll;
	}

	public String getStringconcatAll() {

		String forconcatall = "[";

		for(int i=0; i<this.getconCatAll.length; i++) {

			forconcatall += this.getconCatAll[i];
			if(this.getconCatAll.length - i != 1) {
				forconcatall += ", ";
			}
		}
		forconcatall += "]";
		return forconcatall;
	}


	@Override
	public String toString() {
		this.conCatAll();
		String result = null;
		if(this.notconcat == 0) {
			
			result = "Concat(";

			for(int i=0; i<this.noco; i++) {
				if(this.seqo[i] instanceof Projection){
					result += ((Projection) this.seqo[i]).getStringprojection();
				}
				else if(this.seqo[i] instanceof SumsOfPrefixes) {
					result += ((SumsOfPrefixes) this.seqo[i]).getStringSums();

				}
				if(this.noco - i != 1) {
					result += ", ";
				}
			}

			result += String.format(") = %s", this.getStringconcatAll());
		}
		else {
			result = String.format("Concat cannot be evaluated due to %d incompatile operations.", this.notconcat);
		}


		return result;

	}




}
