package model;

public class BinarySeqOperation extends SeqOperation{
	
	public BinarySeqOperation(int[] a, int[] b) {
		super(a,b);
		
	}

}
