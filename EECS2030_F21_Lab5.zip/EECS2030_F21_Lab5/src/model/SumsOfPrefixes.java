package model;

public class SumsOfPrefixes extends SeqOperation {
		
	public SumsOfPrefixes(int[] seq1) {
		super(seq1);
		this.SumsofPrefixes();
		
	}
	
	public int[] getSumsofPrefixes() {
		return this.SumsofPrefixes();
	}
	
	public int[] SumsofPrefixes() {
		
		if(this.seq1.length == 0) {
			return this.seq1;
		}
		int[] temp = new int[this.seq1.length + 1];
		temp[0] = 0;
		int k = 1;
		while(k<temp.length) {
			int j = 0;
			
			while(j<this.seq1.length && j<k) {
				temp[k] += this.seq1[j];
				j++;
			}
			k++;
		}
		
		return temp;
	}
	
	public String getStringSums() {
		String forsum = "[";

		for(int i=0; i<this.getSumsofPrefixes().length; i++) {

			forsum += this.getSumsofPrefixes()[i];
			if(this.getSumsofPrefixes().length - i != 1) {
				forsum += ", ";
			}
		}
		forsum += "]";
		return forsum;
		
	}

	@Override
	public String toString() {
		
		String result = null;
		
		result = String.format("Sums of prefixes of %s is: %s", this.getStringSeq1(), this.getStringSums());
		
		return result;
	}
	
	

}
