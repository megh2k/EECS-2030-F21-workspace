package model;

public class OccursWithin extends BinarySeqOperation {

	public OccursWithin(int[] a, int[] b) {
		super(a, b);
		this.occuringWithin();
	}

	public boolean occuringWithin() {
		boolean flag = true;
		
		if(this.seq1.length == 0 || this.seq2.length == 0) {
			return true;
		}

		int i = 0;
		boolean found = false;
		while(i<this.seq2.length) {
			
			if(this.seq2[i] == this.seq1[0]) {
				found = true;

				int j = i;
				int k = 0;

				while(k<this.seq1.length && flag) {
					
					if(this.seq1[k] != this.seq2[j]) {
						flag = false;	
					}
					
					j++;
					k++;
				}
				if(flag == true) {
					break;
				}

			}
			i++;
		}
		
		if(found == false) {
			flag = found;
		}
		
		return flag;

	}

	@Override
	public String toString() {
		
		String result = null;
		
		String decide = null;
		
		if(this.occuringWithin() == true) {
			decide = "occurs within";
		}
		else {
			decide = "does not occur within";
		}
		
		result = String.format("%s %s %s", this.getStringSeq1(),decide, this.getStringSeq2());
		return result;
		
		
	}
	
	


}
