package model;

public class SeqOperation {
	protected int[] seq1;
	protected int[] seq2;

	

	public SeqOperation(int[] a, int[] b) {

		this.seq1 = a;
		this.seq2 = b;

	}
	
	public SeqOperation(int[] a) {
		seq1 = a;
	}

	public String getStringSeq1() {
		String forseq1 = "[";

		for(int i=0; i<this.seq1.length; i++) {

			forseq1 += this.seq1[i];
			if(this.seq1.length - i != 1) {
				forseq1 += ", ";
			}
		}
		forseq1 += "]";
		return forseq1;
		
	}
	
	public String getStringSeq2() {
		String forseq2 = "[";

		for(int i=0; i<this.seq2.length; i++) {

			forseq2 += this.seq2[i];
			if(this.seq2.length - i != 1) {
				forseq2 += ", ";
			}
		}
		forseq2 += "]";
		return forseq2;
		
	}
	
	

	


}
