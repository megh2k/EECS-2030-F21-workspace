package model;

public abstract class SeqEvaluator{
	protected SeqOperation[] seqo;
	protected int noco;
	protected int[] getconCatAll;
	protected int notconcat;
	
	public SeqEvaluator(int x) {
		this.seqo = new SeqOperation[x];
		this.noco = 0;
		this.notconcat = 0;
		
	}



	public abstract void addOperation(String string, int[] seq1, int[] seq2) throws IllegalOperationException;



}
