package model;

public class FilterAll extends SeqEvaluator {


	public FilterAll(int x) {
		super(x);
	}

	@Override
	public void addOperation(String s, int[] a, int[] b) throws IllegalOperationException{

		if(s.equals("op:projection")) {
			this.notconcat ++;
			this.noco--;		}

		else if(s.equals("op:sumsOfPrefixes")){
			this.notconcat ++;
			this.noco--;		}

		else if(s.equals("op:occursWithin")) {
			this.seqo[this.noco] = new OccursWithin(a, b);

		}
		else {
			throw new IllegalOperationException(s);
		}

		this.noco++;

	}

	public String[] filterAll() {

		int length = this.noco;
		String[] temp = new String[length]; 


		for(int i=0; i<this.noco; i++) {
			if(((OccursWithin) this.seqo[i]).occuringWithin() == true) {
				temp[i] = "true";
			}
			else {
				temp[i] = "_";
			}
		}
		return temp;

	}

	public String getStringfilterAll() {

		String forfilterAll = "";

		for(int i=0; i<this.filterAll().length; i++) {

			forfilterAll += this.filterAll()[i];
			if(this.filterAll().length - i != 1) {
				forfilterAll += ", ";
			}
		}
		return forfilterAll;
	}

	@Override
	public String toString() {
		this.filterAll();

		String result = null;

		if(this.notconcat == 0) {
			result = String.format("Filter result is: %s", this.getStringfilterAll());
		}
		else {
			result = String.format("Filter cannot be evaluated due to %d incompatile operations.", this.notconcat);
		}

		return result;



	}

















}
