package model;

public class Projection extends BinarySeqOperation {
	private int[] projecting;
	private int index;


	public Projection(int[] seq1, int[] seq2) {
		super(seq1, seq2);	
		this.projecting();
		index = 0;

	}
	
	public int[] getProjecting() {
		return this.projecting;
	}

	public void projecting() {

		int[] temp = new int[this.seq2.length];

		for(int i=0; i<this.seq2.length; i++) {

			for(int j=0; j<this.seq1.length; j++) {

				if(this.seq2[i] == this.seq1[j]) {
					temp[index] = this.seq1[j];
					index++;
					break;
				}
			}
		}


		this.projecting = new int[index];

		for(int i=0; i<index; i++) {
			this.projecting[i] = temp[i];
		}


	}
	
	public int getIndex() {
		return this.index;
	}
	
	
	public String getStringprojection() {
		String forprojecting = "[";

		for(int i=0; i<this.projecting.length; i++) {

			forprojecting += this.projecting[i];
			if(this.projecting.length - i != 1) {
				forprojecting += ", ";
			}
		}
		forprojecting += "]";
		return forprojecting;
	}

	@Override
	public String toString() {
		String result = null;


		result = String.format("Projecting %s to %s results in: %s", this.getStringSeq1(), this.getStringSeq2(), this.getStringprojection());

		return result;
	}






}
