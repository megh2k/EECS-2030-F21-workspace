package model;

public class Floor {

	private int area;
	private String update;
	private int usedSpace;
	private int leftSpace;
	private Unit[] units;
	private int nou;	//number of units added

	public Floor(int area) {
		this.area = area;
		this.usedSpace = 0;
		this.units = new Unit[20];
		this.leftSpace = this.area - this.usedSpace;
	}
	
	public Floor(Floor obj) {
		
		this(obj.area);
		this.area = obj.area;
		this.usedSpace = obj.usedSpace;
		this.units = obj.units;
		this.leftSpace = obj.leftSpace;
		this.nou = obj.nou;
		
		Unit[] temp = new Unit[obj.nou];
		
		for(int i=0; i<this.nou; i++) {
			temp[i] = this.units[i];
		}
		
		for(int i=0; i<temp.length; i++) {
			
			Unit b = new Unit(temp[i]);			
			this.units[i] = b;
		}
	}

	public void addUnit(String s, int a, int b) throws InsufficientFloorSpaceException {

		if(this.leftSpace<= a*b) {
			throw new InsufficientFloorSpaceException(s);
		}
		else {
			this.units[this.nou] = new Unit(s, a, b);
			this.usedSpace += a*b;
			this.leftSpace = this.area - this.usedSpace;
			this.nou++;
		}

	}
	
	public Unit[] getUnits() {
		return this.units;
	}

	public boolean equals(Object obj) {
		boolean fine = false;

		if(obj == null) {
			return false;
		}
		

		Floor temp = (Floor) obj;

		if(this.area != temp.area) {
			return false;
		}
		
		if(this.nou != temp.nou) {
			return false;
		}
		
		else {
			int count = 0;

			for(int i=0; i<this.nou; i++) {
				boolean flag = false;

				for(int j=0; j<temp.nou  && !flag; j++) {

					if(this.units[i].getFunction().equals(temp.units[j].getFunction()) && this.units[i].getArea() == temp.units[j].getArea()){
						flag = true;
						count ++;
					}
				}

				if(!flag) {
					break;
				}
				
			}
			if(count== this.nou) {
				fine = true;
			}
		}


		return fine;

	}

	@Override
	public String toString() {

		if(this.nou == 0) {
			this.update = String.format("Floor's utilized space is %d sq ft (%d sq ft remaining): []", this.usedSpace, this.leftSpace);

		}
		else {

			Unit[] temp = new Unit[this.nou];

			for(int i=0; i<this.nou; i++) {
				temp[i] = this.units[i];
			}

			this.update = String.format("Floor's utilized space is %d sq ft (%d sq ft remaining): [", this.usedSpace, this.leftSpace);

			for(int j=0; j<this.nou; j++) {

				if(this.nou-j == 1) {
					this.update += temp[j].getforFloor() + "]";
				}
				else {
					this.update += temp[j].getforFloor() +", ";
				}
			}


		}

		return this.update;
	}



}
