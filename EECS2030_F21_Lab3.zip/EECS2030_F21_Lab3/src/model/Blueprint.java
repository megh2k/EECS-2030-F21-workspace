package model;

public class Blueprint {
	
	private int notf;		//total number of floors in the building
	private Floor[] floors;
	private int nocf;		//current number of floors in the building
	private String update;
	private float per;
	
	public Blueprint(int x) {
		this.notf = x;
		floors = new Floor[this.notf];
		this.update = null;
		this.per = (float) 0.0;
		
	}
	public Blueprint(Blueprint b) {
		this(b.notf);
		this.floors = new Floor[this.notf];
		this.nocf = b.nocf;
		this.update = new String(b.update);
				
		for(int i=0; i<this.nocf; i++) {
			this.floors[i] = b.floors[i];
		}
			
	}
	
	
	public void addFloorPlan(Floor obj) {
		this.floors[this.nocf] = obj;
		this.nocf++;
		
	}
	
	public Floor[] getFloors() {
		
		Floor[] temp = new Floor[this.nocf];
		
		for(int i=0; i<this.nocf; i++) {
			Floor newpain = new Floor(this.floors[i]);
			temp[i] = newpain;
		}
		return temp;
	}

	@Override
	public String toString() {
		this.per = ((float)this.nocf*100/this.notf);
		
		this.update = String.format("%.1f percents of building blueprint completed (%d out of %d floors)", this.per, this.nocf, this.notf);

		return update;
	}
	
	

}
