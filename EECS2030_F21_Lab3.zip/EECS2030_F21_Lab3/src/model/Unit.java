package model;

public class Unit {
	
	private String function;
	private int feet1;
	private int feet2;
	private String update;
	private String forFloor;
	private int flip;
	
	public Unit(String s, int a, int b) {
		this.function = s;
		this.feet1 = a;
		this.feet2 = b;
		this.flip = 0;
		this.update = String.format("A unit of %d square feet (%d' wide and %d' long) functioning as %s", this.getArea(), this.feet1, this.feet2, this.function);
		this.forFloor = String.format("%s: %d sq ft (%d' by %d')", this.function, this.getArea(), this.feet1, this.feet2);
		
	}
	
	public Unit(Unit object) {
		this(new String(object.function), object.feet1, object.feet2);
	}
	
	public int getfeet1() {
		return this.feet1;
	}
	public int getfeet2() {
		return this.feet2;
	}
	
	public String getFunction() {
		return this.function;
	}
	
	public void toogleMeasurement() {	//changing feet to meter
		double meter1 = this.feet1*0.3048;
		double meter2 = this.feet2*0.3048;
		flip++;
		
		if(flip %2 != 0) {
			this.update = String.format("A unit of %.2f square meters (%.2f m wide and %.2f m long) functioning as %s", meter1*meter2, meter1, meter2, this.function);
		}
		else {
			this.update = String.format("A unit of %d square feet (%d' wide and %d' long) functioning as %s", this.getArea(), this.feet1, this.feet2, this.function);

		}

		
		
	}
	
	public int getArea() {
		return (this.feet1*this.feet2);
	}
	
	public boolean equals(Object obj) {
		
		if(obj == null) {
			return false;
		}
		
		Unit room = (Unit) obj;
		
		return (this.getArea() == room.getArea() && (this.function == room.function));
		
	}
	public String getforFloor() {
		return this.forFloor;
	}

	@Override
	public String toString() {
		return this.update;
	}
	
	
	

}
